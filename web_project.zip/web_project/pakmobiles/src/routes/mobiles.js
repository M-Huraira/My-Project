const express = require('express');
const connectDB = require('../db'); // Import the function to connect to MongoDB
const router = express.Router();

// Routes
router.post('/signup', async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const db = await connectDB();
        const user = await db.collection('users').findOne({ email });
        if (user) {
            return res.status(400).json({ message: 'User already exists' });
        }
        const newUser = {
            name,
            email,
            password: password,
        };

        await db.collection('users').insertOne(newUser);
        res.status(200).json({ message: 'User registered successfully' });
    } catch (err) {
        console.error('Error registering user:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Endpoint to delete mobile device
router.delete('/api/mobiles/:name', async (req, res) => {
    const { name } = req.params;
    try {
        const db = await connectDB();
        const result = await db.collection('mobiles').deleteOne({ name });
        if (result.deletedCount === 1) {
            res.status(200).json({ message: 'Mobile deleted' });
        } else {
            res.status(404).json({ message: 'Mobile not found' });
        }
    } catch (err) {
        console.error('Error deleting mobile:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Endpoint to fetch all mobiles
router.get('/api/mobiles', async (req, res) => {
    try {
        const db = await connectDB();
        const mobiles = await db.collection('mobiles').find({}).toArray();
        res.json(mobiles);
    } catch (err) {
        console.error('Error fetching mobiles:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Endpoint to fetch unique brands
router.get('/api/mobiles/brands', async (req, res) => {
    try {
        const db = await connectDB();
        const brands = await db.collection('mobiles').distinct('brand');
        res.json(brands);
    } catch (err) {
        console.error('Error fetching brands:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


// Endpoint to fetch all prices
router.get('/api/mobiles/prices', async (req, res) => {
    try {
        const db = await connectDB();
        const mobiles = await db.collection('mobiles').find({}).toArray();
        const prices = mobiles.map(mobile => mobile.price);
        res.json(prices);
    } catch (err) {
        console.error('Error fetching prices:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


// Endpoint to update a mobile's rating
router.put('/api/mobiles/:name', async (req, res) => {
    try {
        const db = await connectDB();
        const updatedMobile = await db.collection('mobiles').findOneAndUpdate(
            { name: req.params.name },
            { $set: { rating: req.body.rating } },
            { returnOriginal: false }
        );
        res.json(updatedMobile.value);
    } catch (err) {
        console.error('Error updating mobile:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Endpoint to fetch a single mobile by name
router.get('/api/mobiles/:name', async (req, res) => {
    try {
        const db = await connectDB();
        const mobile = await db.collection('mobiles').findOne({ name: req.params.name });
        if (!mobile) {
            res.status(404).json({ error: 'Mobile not found' });
        } else {
            res.json(mobile);
        }
    } catch (err) {
        console.error('Error fetching mobile:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Endpoint to fetch messages between two users
router.get('/api/messages/:user1/:user2', async (req, res) => {
    try {
        const db = await connectDB();
        const messages = await db.collection('messages').find({
            $or: [
                { sender: req.params.user1, receiver: req.params.user2 },
                { sender: req.params.user2, receiver: req.params.user1 }
            ]
        }).sort({ time: 1 }).toArray(); // Sort by time in ascending order
        res.json(messages);
    } catch (err) {
        console.error('Error fetching messages:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Endpoint to send a message from one user to another
router.post('/api/messages', async (req, res) => {
    try {
        const db = await connectDB();
        const message = {
            sender: req.body.sender,
            receiver: req.body.receiver,
            text: req.body.text,
            time: new Date()
        };
        await db.collection('messages').insertOne(message);
        res.status(200).json({ message: 'Message sent successfully' });
    } catch (err) {
        console.error('Error sending message:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


// // Chat and Message schemas
// const chatSchema = new mongoose.Schema({
//   chatId: Number,
//   title: String,
//   avatarFilename: String
// });

// const messageSchema = new mongoose.Schema({
//   messageId: Number,
//   chatId: Number,
//   text: String,
//   sender: String
// });
// const Chat = mongoose.model('chats', chatSchema);
// const Message = mongoose.model('messages', messageSchema);

// app.post('/login', async (req, res) => {
//   const { email, password } = req.body;
//   console.log('Login request body:', req.body); // Add this line
//   try {

//     const user = await User.findOne({ email, password });
//     console.log('Found user:', user); // Add this line
//     if (user) {
//       res.status(200).send('Login successful');
//     } else {
//       res.status(401).send('Invalid email or password');
//     }
//   } catch (error) {
//     res.status(500).send('Error during login');
//   }
// });


// // Get all chats
// app.get('/chats', async (req, res) => {
//   try {
//     const chats = await Chat.find();
//     console.log('Retrieved chats:', chats); // Log retrieved chats
//     res.json(chats);
//   } catch (error) {
//     console.error('Error fetching chats:', error); // Log error
//     res.status(500).json({ error: 'Error fetching chats' });
//   }
// });

// // Get messages for a specific chat
// app.get('/messages/:chatId', async (req, res) => {
//   const chatId = req.params.chatId;
//   try {
//     const messages = await Message.find({ chatId });
//     console.log(`Retrieved messages for chatId ${chatId}:`, messages); // Log retrieved messages
//     res.json(messages);
//   } catch (error) {
//     console.error(`Error fetching messages for chatId ${chatId}:`, error); // Log error
//     res.status(500).json({ error: 'Error fetching messages' });
//   }
// });

// // Get messages for a specific user
// app.get('/messages/:id', async (req, res) => {
//   const userId = req.params.id;
//   try {
//     const messages = await Message.aggregate([
//       {
//         $lookup: {
//           from: 'chats',
//           localField: 'chatId',
//           foreignField: 'chatId',
//           as: 'chat',
//         },
//       },
//       {
//         $match: {
//           $or: [
//             { 'chat.sender_id': parseInt(userId) },
//             { 'chat.receiver_id': parseInt(userId) },
//           ],
//         },
//       },
//       {
//         $project: {
//           messageId: 1,
//           chatId: 1,
//           message: 1,
//           sender_id: {
//             $cond: {
//               if: { $eq: ['$chat.sender_id', parseInt(userId)] },
//               then: parseInt(userId),
//               else: '$chat.receiver_id',
//             },
//           },
//         },
//       },
//     ]);
//     console.log(`Retrieved messages for userId ${userId}:`, messages);
//     res.json(messages);
//   } catch (error) {
//     console.error(`Error fetching messages for userId ${userId}:`, error);
//     res.status(500).json({ error: 'Error fetching messages' });
//   }
// });



module.exports = router;