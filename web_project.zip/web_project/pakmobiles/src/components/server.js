const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mobilesRouter = require('../routes/mobiles'); // Import the router for mobiles
const connectDB = require('../db'); // Import the function to connect to MongoDB


const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use('', mobilesRouter); // Mount the mobiles router

// Connect to MongoDB
connectDB()
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('Error connecting to MongoDB:', err));

// Start the server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
